package Match;

import java.util.ArrayList;

public interface Scheduler {
    void addToSchedule(ArrayList<CourseSchedule> allCourses) throws Exception;
}
