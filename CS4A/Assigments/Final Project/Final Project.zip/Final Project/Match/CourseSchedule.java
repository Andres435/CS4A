/**
 * Class that Schedule this semester Courses and Sesisons
 */
package Match;

import Course.*;
import Files.WriteFiles;

public class CourseSchedule{
    private Course course;
    private int minCapacity;
    private int maxcapacity;
    private SessionSet sessions;

    public CourseSchedule(Course course, int minCapacity, int maxCapacity, SessionSet sessions) {
        this.course = course;
        this.minCapacity = minCapacity;
        this.maxcapacity = maxCapacity;
        this.sessions = sessions;
    }

    
    /** 
     * getCourse -- get course data
     * 
     * @author Andres Quintana
     * @return Course
     */
    public Course getCourse() {
        return course;
    }

    
    /** 
     * setCourse -- set course data
     * 
     * @author Andres Quintana
     * @param course
     */
    public void setCourse(Course course) {
        this.course = course;
    }

    
    /** 
     * getMinCapacity -- get Min paramenter for Sesion
     * 
     * @author Andres Quintana
     * @return int
     */
    public int getMinCapacity() {
        return minCapacity;
    }

    
    /** 
     * setMinCapacity -- set Min paramenter for Sesion
     * 
     * @author Andres Quintana
     * @param minCapacity
     */
    public void setMinCapacity(int minCapacity) {
        this.minCapacity = minCapacity;
    }

    
    /** 
     * getMaxCapacity -- get Max paramenter for Sesion
     * 
     * @author Andres Quintana
     * @return int
     */
    public int getMaxcapacity() {
        return maxcapacity;
    }

    
    /** 
     * setMaxCapacity -- set Max paramenter for Sesion
     * 
     * @author Andres Quintana
     * @param maxcapacity
     */
    public void setMaxcapacity(int maxcapacity) {
        this.maxcapacity = maxcapacity;
    }

    
    /** 
     * getSessionSet -- get SesionSet variable
     * 
     * @author Andres Quintana
     * @return SessionSet
     */
    public SessionSet getSessions() {
        return sessions;
    }

    
    /** 
     * setSessionSet -- set SesionSet variable
     * 
     * @author Andres Quintana
     * @param sessions
     */
    public void setSessions(SessionSet sessions) {
        this.sessions = sessions;
    }

    
    /** 
     * writeFile -- Save data into a file
     * 
     * @author Andres Quintana
     * @param scheduled
     * @param unscheduled
     * @throws Exception
     */
    public void writeFile(WriteFiles scheduled, WriteFiles unscheduled) throws Exception {
        if(sessions.getSessions().size() == 0) {
            unscheduled.writeToFile("Unscheduled Course: " + course +  "Min Capacity to Schedule: " + minCapacity + "\n");
        }
        else{
            scheduled.writeToFile("CourseSchedule: " + course + "Max Capacity: " + maxcapacity + "\nMin Capacity: " + minCapacity);
            for(int i = 0; i < sessions.getSessions().size(); i++){
                scheduled.writeToFile("Session Id: " + sessions.getSessions().get(i).getSessionId());
                scheduled.writeToFile("Professor: : " + sessions.getSessions().get(i).getProfessor().getFullName());
                scheduled.writeToFile("Professor Id: " + sessions.getSessions().get(i).getProfessor().getId());
                scheduled.writeToFile("Students In Session: " + sessions.getSessions().get(i).getStudents().getStudents().size());
                for(int j = 0; j < sessions.getSessions().get(i).getStudents().getStudents().size(); j++){
                    scheduled.writeToFile("Student: " + sessions.getSessions().get(i).getStudents().getStudents().get(j).getFullName());
                    scheduled.writeToFile("Students Id: " + sessions.getSessions().get(i).getStudents().getStudents().get(j).getId() + "\n");
                }
            }
        }
    }

    
    /** 
     * printSchedule -- Print data into the console
     * 
     * @author Andres Quintana
     * @throws Exception
     */
    public void printCourses() throws Exception {
        if(sessions.getSessions().size() == 0) {
            System.out.println( "\nUnschedule Course: " + course +  "Min Capacity to Schedule: " + minCapacity);
        }
        else{
            System.out.println( "\nCourseSchedule: " + course + "Max Capacity: " + maxcapacity + "\nMin Capacity: " + minCapacity);
            for(int i = 0; i < sessions.getSessions().size(); i++){
                System.out.println("Session Id: " + sessions.getSessions().get(i).getSessionId());
                System.out.println("Professor: : " + sessions.getSessions().get(i).getProfessor().getFullName());
                System.out.println("Professor Id: " + sessions.getSessions().get(i).getProfessor().getId());
                System.out.println("Students In Session: " + sessions.getSessions().get(i).getStudents().getStudents().size());
                for(int j = 0; j < sessions.getSessions().get(i).getStudents().getStudents().size(); j++){
                    System.out.println("Student: " + sessions.getSessions().get(i).getStudents().getStudents().get(j).getFullName());
                    System.out.println("Students Id: " + sessions.getSessions().get(i).getStudents().getStudents().get(j).getId());
                }
            }
        }
    }
}
