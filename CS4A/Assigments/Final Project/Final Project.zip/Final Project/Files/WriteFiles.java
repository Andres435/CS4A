package Files;

import java.io.IOException;
import java.io.FileWriter;
import java.io.PrintWriter;

import Course.Course;
import Persona.Professor;
import Persona.Student;

public class WriteFiles{
    private String path;
    private boolean append_to_file;

    public WriteFiles(String path) throws IOException {
        append_to_file = false;
        this.path = path;
        this.emptyFile();
    }

    public WriteFiles(String path, boolean append_to_file) {
        this.path = path;
        this.append_to_file = append_to_file;
    }

    
    /** 
     * writeToFile-- Write String into file
     * 
     * @author Andres Quintana
     * @param textLine
     * @throws IOException
     */
    public void writeToFile( String textLine ) throws IOException {
        append_to_file = true;
        FileWriter write = new FileWriter(path, append_to_file);
        PrintWriter print_line = new PrintWriter(write);
        
        print_line.printf("%s" + "%n", textLine);
        print_line.close();
    }

    
    /** 
     * writeToFile-- Write Course into file
     * 
     * @author Andres Quintana
     * @param course
     * @throws IOException
     */
    public void writeFile( Course course) throws IOException {
        append_to_file = true;
        FileWriter write = new FileWriter(path, append_to_file);
        PrintWriter print_line = new PrintWriter(write);
        
        print_line.printf("%s" + "%n", course);
        print_line.close();
    }

    
    /** 
     * writeToFile-- Write Student into file
     * 
     * @author Andres Quintana
     * @param student
     * @throws IOException
     */
    public void writeFile( Student student) throws IOException {
        append_to_file = true;
        FileWriter write = new FileWriter(path, append_to_file);
        PrintWriter print_line = new PrintWriter(write);
        
        print_line.printf("%s" + "%n", student);
        print_line.close();
    }

    
    /** 
     * writeToFile-- Write Professor into file
     * 
     * @author Andres Quintana
     * @param professor
     * @throws IOException
     */
    public void writeFile( Professor professor) throws IOException {
        append_to_file = true;
        FileWriter write = new FileWriter(path, append_to_file);
        PrintWriter print_line = new PrintWriter(write);
        
        print_line.printf("%s" + "%n", professor);
        print_line.close();
    }

    
    /** 
     * emptyFile-- Clear File
     * 
     * @author Andres Quintana
     * @throws IOException
     */
    public void emptyFile() throws IOException {
        append_to_file = false;
        FileWriter write = new FileWriter(path, append_to_file);
        PrintWriter print_line = new PrintWriter(write);
        print_line.println();
        print_line.close();
    }
}
