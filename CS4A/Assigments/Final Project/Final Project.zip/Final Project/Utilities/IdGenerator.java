package Utilities;

public interface IdGenerator {
    public String generateId();
}
