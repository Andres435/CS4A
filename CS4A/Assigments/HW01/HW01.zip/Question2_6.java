/**
 * A program that reads an integer between 0 and 1000 an adds all the digits in the integer.
 */
import java.util.Scanner;

public class Question2_6{
    public static void main(String[] word){
        Scanner input = new Scanner(System.in);
        System.out.print("Enter a Integer between 0 and 1000: ");
        int number = input.nextInt();

        int hundreds = number / 100;
        int tens = (number / 10) % 10;
        int unit = number % 10;

        int sum = hundreds + tens + unit;

        System.out.println("The sum of the digits is: " + sum);
        input.close();
    }
}